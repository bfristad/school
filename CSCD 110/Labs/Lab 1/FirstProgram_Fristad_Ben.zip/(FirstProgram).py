age = int(input("What is your age: "))

hours = age * 365 * 24

print("You are", hours, "old")
