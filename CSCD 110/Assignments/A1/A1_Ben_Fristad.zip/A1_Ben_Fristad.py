#1.1
#1/15/20
#A1

#Ask the user for 2 non-zero, integer numbers
num1 = int(input("Enter a number: "))
num2 = int(input("Enter another number: "))
#Add the two numbers and display output
print("The sum of", num1, "and", num2, "is", num1 + num2)
#Subtract the second number from the first and display output
print("The difference of", num1, "and", num2, "is", num1 - num2)
#Multiply the 2 numbers and display output
print("The product of", num1, "and", num2, "is", num1 * num2)
#Raise the first number to the second and display output
print(num1, "raised to the power of", num2, "is", num1 ** num2)
#Divide the first number by the second using integer division and display output
print("The quotient of", num1, "and", num2, "is", num1 // num2)
#Find the remainder of dividing the first number by the second and display output
print("The remainder of the quotient", num1 % num2)
